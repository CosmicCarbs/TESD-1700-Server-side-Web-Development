<!DOCTYPE html>
<html>
<head>
   <title>Info Extracted</title>
</head>
<body>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($_POST['info']) {
        case 'userId':
        case 'id':
        case 'title':
        case 'completed':

            $url = 'https://jsonplaceholder.typicode.com/todos/1';

            $contents = file_get_contents($url);
            if (!$contents) {
                die('Failed to open ' . $url);
            }

            $data = json_decode($contents, true); 

            if (isset($data[$_POST['info']])) {
                $value = $data[$_POST['info']];

                if (is_bool($value)) {
                    $value = $value ? 'true' : 'false';
                }

                echo "<h2>" . htmlspecialchars($_POST['info']) . ": " . htmlspecialchars($value) . "</h2>";
            } else {
                echo "<h1><span style=\"color: red;\">WARNING:</span><br/> Requested info not found.</h1>";
            }

            break;

        default:
            echo "<h1><span style=\"color: red;\">WARNING:</span><br/> Invalid input value specified.</h1>";
            break;
    }
} else {
    echo "<h1><span style=\"color: red;\">WARNING:</span><br/> No POST data received.</h1>";
}
?>

</body>
</html>
