<?php
class Page
{
  public $content;
  public $title = "Gaming Studios";
  public $keywords = "Gaming Studios, Games made by Gamers, We Listen and Apply";
  public $buttons = array(
    "Home" => ["url" => "homepage.php"],
    "Donate" => ["url" => "donate.php"],
    "Contact Us" => ["url" => "contactus.php"],
    "Survey" => ["url" => "randomsurvey.html"],
  );
  public $cssFile = "format.css";
  public $headerTitle = "Gaming Studios";  
  public $footerText = "Bottom Text for Meme";

  public function __set($name, $value)
  {
    $this->$name = $value;
  }

  public function Display()
  {
    echo "<html>\n<head>\n";
    $this->DisplayMeta();
    $this->DisplayStyles();
    echo "</head>\n<body>\n";
    $this->DisplayHeader();
    $this->DisplayMenu($this->buttons);
    echo $this->content;  // Directly output content (without htmlspecialchars)
    $this->DisplayFooter();
    echo "</body>\n</html>\n";
  }

  public function DisplayMeta()
  {
    echo '<meta charset="UTF-8">';
    echo "<title>" . htmlspecialchars($this->title, ENT_QUOTES, 'UTF-8') . "</title>";
    echo "<meta name='keywords' content='" . htmlspecialchars($this->keywords, ENT_QUOTES, 'UTF-8') . "' />";
  }

  public function DisplayStyles()
  {
    echo '<link href="' . $this->cssFile . '" type="text/css" rel="stylesheet">';
  }

  public function DisplayHeader()
  {
    echo "<header><h1>" . $this->headerTitle . "</h1></header>";
  }

  public function DisplayMenu($buttons)
  {
    echo "<nav>";
    foreach ($buttons as $name => $data) {
      $this->DisplayButton($name, $data['url']);
    }
    echo "</nav>\n";
  }

  public function IsURLCurrentPage($url)
  {
    return strpos($_SERVER['PHP_SELF'], $url) !== false;
  }

  public function DisplayButton($name, $url, $active = true)
  {
    echo '<div class="menuitem"><a href="' . $url . '"><span class="menutext">' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '</span></a></div>';
  }

  public function DisplayFooter()
  {
    echo "<footer><h2>" . htmlspecialchars($this->footerText, ENT_QUOTES, 'UTF-8') . "</h2></footer>";
  }
}
?>
