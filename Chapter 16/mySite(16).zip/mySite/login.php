<!DOCTYPE html>
<html>
<head>
   <title>Secret Page</title>
</head>
<body>

<?php
  if ((!isset($_POST['name'])) || (!isset($_POST['password']))) {
  // visitor needs to enter a name and password
?>
    <h1>Please Log In</h1>
    <p>This page is secret.</p>
    <form method="post" action="login.php">
    <p><label for="name">Username:</label>
    <input type="text" name="name" id="name" size="15" /></p>
    <p><label for="password">Password:</label>
    <input type="password" name="password" id="password" size="15" /></p>
    <button type="submit" name="submit">Log In</button>
    </form>
<?php
  } else if(($_POST['name']=='user1') && ($_POST['password']=='password!')) {
    // visitor's name and password combination are correct
    header("Location: homepage.php");
} else if(($_POST['name']=='user2') && ($_POST['password']=='Ilike2code')) {
    // visitor's name and password combination are correct
    header("Location: homepage.php");
} else if(($_POST['name']=='user3') && ($_POST['password']=='nintendo123')) {
    // visitor's name and password combination are correct
    header("Location: homepage.php");
} else if(($_POST['name']=='user4') && ($_POST['password']=='cyaApple!')) {
    // visitor's name and password combination are correct
    header("Location: homepage.php");
  } else {
    // visitor's name and password combination are not correct
    echo '<h1>Inncorrect</h1>';
  }
?>
</body>
</html>