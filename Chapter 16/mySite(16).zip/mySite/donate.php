<?php
  require('header.php');
?>
    <form action="processdonate.php" method="post" >
    <figure>
        <table>
            <tr id="rowTitles">
                <td>Donation Size</td>
                <td>Bonus Gift</td> 
            </tr>
            <tr>
                <td>$5.00 to $10.00</td>
                <td>Limited Edition Pin</td>
            </tr>
            <tr>
                <td>$10.01 to $20.00</td>
                <td>Pin + Steam Game Code</td>
            </tr>
            <tr>
                <td>$20.01 or MORE</td>
                <td>Pin + Game + Beta Test</td>
            </tr>
        </table>
        <figcaption><br />*codes will be given for each bonus gift after donation submitted</figcaption>
        <p>Name: <input type="text" name="name" /></p>
        <p>Donation Amount: $<input type="text" name="donate" /></p>
        <input type="submit" value="Submit Donation" />
    </figure>
<?php
    require('footer.php');
  ?>