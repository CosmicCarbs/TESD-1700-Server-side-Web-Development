<?php
switch ($_POST['q1']) {
case 'agree':
case 'neutral':
case 'disagree':
break;
default:
echo "<h1><span style=\"color:red;\">WARNING:</span><br/>
Invalid input value specified for Question 1.</h1>";
break;
}
?>
<?php
switch ($_POST['q2']) {
case 'agree':
case 'neutral':
case 'disagree':
break;
default:
echo "<h1><span style=\"color:red;\">WARNING:</span><br/>
Invalid input value specified for Question 2.</h1>";
break;
}
?>
<?php
switch ($_POST['q3']) {
case 'agree':
case 'neutral':
case 'disagree':
break;
default:
echo "<h1><span style=\"color:red;\">WARNING:</span><br/>
Invalid input value specified for Question 3.</h1>";
break;
}
?>
<?php
switch ($_POST['q4']) {
case 'agree':
case 'neutral':
case 'disagree':
break;
default:
echo "<h1><span style=\"color:red;\">WARNING:</span><br/>
Invalid input value specified for Question 4.</h1>";
break;
}
?>
<?php
switch ($_POST['q5']) {
case 'agree':
case 'neutral':
case 'disagree':
break;
default:
echo "<h1><span style=\"color:red;\">WARNING:</span><br/>
Invalid input value specified for Question 5.</h1>";
break;
}
echo "<h1>Thank you For Your Submission</h1>";
?>