<?php
  require("pagetemplate.php");

  $homepage = new Page();

  $pictures = array('green.png', 'blue.png', 'red.png', 'cat.jpg', 'money.jpg');

  shuffle($pictures);

  $homepage->content = "
      <img src='ad.png' id='ad' />
      <h1>Welcome</h1>
      <figure>
          <a href='donate.php'>
              <img src='" . $pictures[0] . "' alt='Random Image' />
          </a>
          <figcaption>Click to Donate</figcaption>
      </figure>";

  $homepage->Display();
?>

